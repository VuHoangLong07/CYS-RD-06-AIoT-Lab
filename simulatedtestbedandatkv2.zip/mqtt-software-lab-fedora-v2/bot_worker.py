"""Fixed-destination, finite SYN segments and a synthetic heartbeat for one lab namespace."""
import argparse
import csv
import json
import os
import re
import socket
import subprocess
import threading
import time
from pathlib import Path

from lab_common import VICTIM, VICTIM_PORT


def heartbeat(stop, logfile):
    with Path(logfile).open("w", buffering=1) as out:
        while not stop.is_set():
            stamp = time.time()
            try:
                with socket.create_connection((VICTIM, 8081), timeout=2) as sock:
                    sock.sendall(b'{"lab_beacon":true}\n')
                    response = sock.recv(128).decode(errors="replace").strip()
                out.write(json.dumps({"epoch": stamp, "response": response})+"\n")
            except OSError as exc:
                out.write(json.dumps({"epoch": stamp, "error": str(exc)})+"\n")
            stop.wait(5)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", required=True)
    parser.add_argument("--bot", required=True)
    parser.add_argument("--start", type=float, required=True, help="Host monotonic attack start")
    parser.add_argument("--stop-file", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    # Refuse execution in the host network namespace.
    if os.readlink("/proc/self/ns/net") == os.readlink("/proc/1/ns/net"):
        parser.error("Worker must be launched by run_tcp_burst.py inside a lab namespace")
    outdir = Path(args.output)
    segments = [s for s in json.loads(Path(args.plan).read_text())["segments"] if s["bot"] == args.bot]
    if sum(s["count"] for s in segments) > 3000:
        parser.error("Per-node packet budget exceeded")
    stop = threading.Event()
    attack_stop = threading.Event()
    def watch_stop():
        while not stop.wait(0.1):
            if Path(args.stop_file).exists():
                stop.set()
                attack_stop.set()
            if (outdir/"attack.stop").exists():
                attack_stop.set()
    threading.Thread(target=watch_stop, daemon=True).start()
    threading.Thread(target=heartbeat, args=(stop, outdir/f"{args.bot}_beacon.jsonl"), daemon=True).start()
    fields = ["bot", "segment", "planned_offset", "start_epoch", "end_epoch", "source_port",
              "rate_pps", "planned_syn", "reported_sent", "returncode"]
    failed = False
    try:
        with (outdir/f"{args.bot}_events.csv").open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            for index, segment in enumerate(segments):
                if not (1 <= segment["rate"] <= 10 and 1 <= segment["count"] <= 100
                        and 49152 <= segment["source_port"] <= 65535):
                    raise ValueError("Invalid bounded segment")
                delay = max(0, args.start + segment["offset"] - time.monotonic())
                if attack_stop.wait(delay):
                    break
                argv = ["nping", "--tcp", "--flags", "syn", "--source-port", str(segment["source_port"]),
                        "-p", str(VICTIM_PORT), "--rate", str(segment["rate"]),
                        "--count", str(segment["count"]), VICTIM]
                started = time.time()
                process = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                deadline = time.monotonic() + segment["count"]/segment["rate"] + 5
                while process.poll() is None and not attack_stop.wait(0.05):
                    if time.monotonic() >= deadline:
                        process.terminate()
                        break
                if attack_stop.is_set() and process.poll() is None:
                    process.terminate()
                try:
                    output, _ = process.communicate(timeout=3)
                except subprocess.TimeoutExpired:
                    process.kill()
                    output, _ = process.communicate()
                ended = time.time()
                (outdir/f"{args.bot}_segment_{index:03d}.log").write_text(output)
                sent = re.search(r"(?:Raw packets sent|Packets sent):\s*(\d+)", output, re.I)
                writer.writerow({"bot": args.bot, "segment": index, "planned_offset": segment["offset"],
                                 "start_epoch": started, "end_epoch": ended,
                                 "source_port": segment["source_port"], "rate_pps": segment["rate"],
                                 "planned_syn": segment["count"], "reported_sent": sent.group(1) if sent else "",
                                 "returncode": process.returncode})
                handle.flush()
                if process.returncode != 0 or not sent or int(sent.group(1)) != segment["count"]:
                    failed = True
            # Heartbeats span baseline, attack and recovery, including control runs.
            (outdir/f"{args.bot}_syn_done").write_text("done\n")
            while not stop.wait(0.1):
                pass
    except BaseException:
        stop.set()
        raise
    finally:
        stop.set()
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
