"""Python replacement for capture_baseline.sh, also usable on a physical capture interface."""
import argparse
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from lab_common import broker_info, require_tools, restore_owner


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("duration", type=int, nargs="?", default=300)
    parser.add_argument("output", nargs="?", default="baseline.pcapng")
    parser.add_argument("--interface", help="Host NIC for Arduino/SPAN capture; default is broker namespace")
    parser.add_argument("--filter", default="tcp port 1883", help="BPF capture filter; quote it")
    args = parser.parse_args()
    if os.geteuid() != 0:
        parser.error("Use sudo python3 capture_baseline.py ...")
    if not 1 <= args.duration <= 3600:
        parser.error("duration must be 1..3600 seconds")
    output = Path(args.output).expanduser().resolve()
    if output.exists():
        parser.error("Output already exists; choose a new filename")
    require_tools(["dumpcap"] + ([] if args.interface else ["docker", "nsenter"]))
    output.parent.mkdir(parents=True, exist_ok=True)
    prefix = [] if args.interface else ["nsenter", "-t", str(broker_info()["pid"]), "-n", "--"]
    directory = Path(tempfile.mkdtemp(prefix="mqtt-capture."))
    # dumpcap may drop to its dedicated account. Sticky writable directory mirrors working V1 fix.
    directory.chmod(0o1777)
    try:
        subprocess.run([*prefix, "dumpcap", "-i", args.interface or "any", "-f", args.filter,
                        "-a", f"duration:{args.duration}", "-w", str(directory/"traffic.pcapng")], check=True)
        shutil.copy2(directory/"traffic.pcapng", output)
        restore_owner(output)
        print(output)
    except KeyboardInterrupt:
        print("Capture interrupted. Partial capture retained at", directory)
        return 130
    except (OSError, subprocess.CalledProcessError) as exc:
        print("Capture failed:", exc, "Partial files:", directory)
        return 1
    else:
        shutil.rmtree(directory)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
