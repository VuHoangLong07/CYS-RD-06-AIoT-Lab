#TCP SYN experiment V2 

I sure hope chatgpt didnt leak my personal files in these texts cuz im not reading allat

Yea note that most of the documentation here was AI generated (was too lazy to type), the accuracy has been confirmed to be within threshold, but there could be discrepancies. V1 was manually deployed but with alot of shortcomings so V2 was born (with the additional help of AI since idk how to create simulated outbound host outside of the main IoT subnet), sorri

Read this first. The original MQTT testbed files are unchanged. V2 adds temporary
Linux network namespaces beside your existing Docker lab. It is a bounded
outbound SYN-traffic experiment, not a promise of denial of service.

## What changed

| V1 limitation | V2 response |
| --- | --- |
| One host attacks Mosquitto | Three separate source IPs route through a gateway to an isolated victim |
| Fixed source port and 50 packets/second | Seeded segments at 2, 3 or 5 SYNs/second per node; changing source ports and gaps |
| 10-second baseline/recovery | Defaults: 60-second baseline, 120-second attack, 60-second recovery |
| Capture/export sees only TCP/1883 | LAN capture includes victim traffic, heartbeats and bot telemetry; second capture sees the broker |
| Bash runner and capture helper | `run_tcp_burst.py` and `capture_baseline.py`, with Python support modules |
| Limited ground truth | Planned, generator-reported and captured SYN counts; actual per-segment timestamps; separate packet labels |
| Broker failure could become the detector shortcut | External victim; MQTT continues; matched no-attack control run |


## Architecture

| Role | Address / connection |
| --- | --- |
| Bot 1 (also runs your unchanged temperature publisher) | 172.30.50.11 |
| Bots 2 and 3 (quiet emulated compromised nodes) | 172.30.50.12 / .13 |
| Lab LAN and capture point | Temporary bridge, 172.30.50.0/24 |
| MQTT relay, on host-side lab bridge | 172.30.50.1:1883 → existing 127.0.0.1:1883 |
| Gateway | LAN 172.30.50.254 / victim side 172.30.60.1 |
| Emulated external victim | 172.30.60.2:8080; separate routed subnet |
| Synthetic heartbeat endpoint | 172.30.60.2:8081 |
| Existing Mosquitto / Node-RED / fan | Original Docker / host configuration |

Analogy: three houses send traffic through a village gate to a building in the
next village. Their local post office (MQTT broker) keeps working. Both villages
are on your PC; neither has an internet exit. Calling a second IP "external"
would be insufficient by itself; the separate subnet and gateway model a boundary.
There is no NAT, WAN latency, real Wi-Fi congestion or real infected firmware.
Bots 2/3 are source emulators, not additional physical Arduinos.

The relay is needed because your original broker is published on loopback.
It changes TCP addresses at the broker-facing capture, so use `traffic.csv`
for bot source attribution. It forwards only to the fixed host MQTT port.
The runner temporarily trusts **only its newly created bridge** in active
Fedora firewalld, and disables bridge netfilter only on that bridge. Cleanup
removes both changes. It does not alter host-wide forwarding or existing zones.

## 1. Install and start the existing testbed

Extract this folder. If you already have the Docker project running, use its
original location: copy the new Python files, tests and guides beside its
`compose.yaml`. Do not launch a second copy of the same Compose project.

```bash
sudo systemctl start docker
sudo dnf install nmap wireshark-cli util-linux iproute procps-ng python3 python3-pip
sudo docker compose config
sudo docker compose up -d
sudo docker compose ps
```

Use your existing working images/volumes. Their availability has not been
verified here. No Docker image, publisher, subscriber, broker config or Node-RED
flow was changed. Do not use `down -v` for routine shutdown.

Create a fresh Python environment; the original archived `.venv` was not portable.

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

Open http://127.0.0.1:1880, import `node-red-flow.json` if needed, and Deploy.
MQTT nodes must connect to `mosquitto:1883`. This flow has a Debug sidebar,
manual ON/OFF buttons and an automatic controller; it has no dashboard/mode switch.

## 2. Start the virtual fan — Terminal A

```bash
.venv/bin/python -u fan_subscriber.py
```

Wait for its subscription confirmation. Keep it running. Leave the host
`temperature_publisher.py` stopped: the V2 runner starts that same script in
bot 1. This avoids two sources publishing the same simulated room readings.
Do not press manual fan buttons during measurements.

## 3. Smoke test, then record — Terminal B
Important note: You don't actually have to run EVERY flag of this script, in a nutshell: No flag (60/120/60 normal TCP flood), --quick (Quick run 2/6/2), --control (same as no flag but doesnt do TCP flood so just acts as a comparison traffic), --seed XX (Like in minecraft, seeds changes behavior of the TCP attack traffic, see the code/code explanation for further details)
Oh right you can just use run_tcp_burst.py -h to see all available options im dumb

```bash
sudo python3 run_tcp_burst.py --quick --python .venv/bin/python
sudo python3 run_tcp_burst.py --python .venv/bin/python
```

The default run lasts about four minutes plus setup/export. It starts the
isolated network, victim, relay, captures, publisher and workers automatically.
Default seed 42 plans **945 SYNs across three nodes**. Counts depend on seed
and duration; `plan.json` is authoritative. Rate limits are low deliberately:
this is a behavioral dataset, not an attempt to saturate your PC.

Run a matched control, then different repeat seeds:

```bash
sudo python3 run_tcp_burst.py --control --python .venv/bin/python
sudo python3 run_tcp_burst.py --seed 67 --python .venv/bin/python
sudo python3 run_tcp_burst.py --seed 69 --python .venv/bin/python
```

For a plan without any traffic or privileged setup:

```bash
python3 run_tcp_burst.py --dry-run
python3 -m unittest discover -s tests -v
```

Each phase accepts 1–300 seconds; there are at most three bots. The standard
plan uses at most 5 SYNs/second per node. Workers also check finite packet budgets.
There is no arbitrary target argument. Ctrl+C retains evidence and cleans up
our services/network. SIGKILL or a power loss cannot guarantee cleanup; see below.

## 4. Inspect each result folder

| File | Purpose |
| --- | --- |
| `traffic.pcapng` / `traffic.csv` | Lab LAN packets: outbound SYNs, beacon stubs, bot 1 MQTT transport |
| `broker.pcapng` / `broker.csv` | Existing sensor/controller/fan MQTT exchanges |
| `victim.pcapng` / `victim.csv` | Victim interface evidence that the routed SYNs actually arrived |
| `labels.csv` | Frame-to-role mapping; attack SYN labels separate from input features |
| `plan.json` | Exact seeded schedule, source IPs and intended packet counts |
| `metadata.json` | Completion/error status, versions, topology and MQTT evidence |
| `timeline.csv` | UTC, epoch and monotonic baseline/attack/recovery markers |
| `bot*_events.csv` | Actual segment times and Nping reported packet counts |
| `syn_summary.json` | Planned vs reported vs LAN-captured vs victim-received SYN counts |
| Capture/worker/relay/publisher/target logs | Drops, failed commands, reconnects and diagnostics |

Only `status: complete` with matching sender, LAN and victim counts is a candidate clean run.
That status confirms this script's checks, not that the fan/hardware/ML model
worked. Verify fan logs and Node-RED Debug output yourself. A run lacking
captured MQTT PUBLISH traffic is marked `no_mqtt_evidence`.

Wireshark filters for `traffic.pcapng`:

```text
ip.dst == 172.30.60.2 && tcp.dstport == 8080 && tcp.flags.syn == 1 && tcp.flags.ack == 0
tcp.port == 1883
tcp.port == 8081
```

Use `mqtt` on `broker.pcapng`. SYN-ACKs and RSTs are expected: Nping sends
raw SYN probes without completing connections, and the node kernel may reset
unsolicited replies. **This does not prove a sustained half-open backlog flood.**

The heartbeat is a fixed JSON request/reply stub throughout all three phases,
including control runs. The coordinator schedules SYNs locally; no real C2,
remote shell, compromise, persistence or malware installation is implemented.
There can be a short transition after `attack_end` while a late segment stops;
`recovery_start` marks when all SYN workers report done. Exclude that transition
from strict window comparisons. Setup packets before `baseline_start` are a prelude.

## 5. ML handoff and hardware follow-up

Use a single capture viewpoint per feature set. Do not concatenate LAN, broker
and victim packet CSVs as if each row were a unique packet; they are overlapping
views. The victim capture verifies delivery. Reassemble flows / make fixed windows before
modeling. Candidate signals: SYN-to-completed-connection imbalance, per-device
new destination/service, source-port diversity and time patterns across sources.
Availability and MQTT rates are measurements, not the definition of "botnet".

Keep identifiers, seed, timeline, synthetic heartbeat markers, run-directory
names and ground truth out of training features. Split train/test by whole runs
and test other seeds; vary benign reconnect behavior in a separate labeled run.
Our ground-truth label marks injected SYNs only. Benign MQTT, replies and
heartbeats inside the attack phase are not relabeled as attack SYNs. C2 stub
activity is annotated separately and occurs in controls too.

For standalone physical MQTT capture (capture host must see the traffic):

```bash
sudo python3 capture_baseline.py 300 physical_baseline.pcapng --interface eno1
```

Substitute the real SPAN/TAP/interface. A PC on a switched network does not
normally see all Arduino packets merely because it is on that network.
Once real telemetry already reaches your existing broker, a concurrent run is:

```bash
sudo python3 run_tcp_burst.py --no-publisher --mqtt-interface eno1
```

That records **real MQTT alongside simulated outbound bots**. It does not make
an Arduino send SYNs or expose it to shared Wi-Fi contention. The unchanged
loopback-only Docker port cannot accept direct remote Arduino connections;
use your team's already working physical broker arrangement. Binding MQTT to a
lab LAN address would be a justified later configuration change, with ACL/auth
and capture placement agreed by the testbed engineer. No such change is made here.
Python/Nping run on Linux, not on UNO R4 firmware. Follow `HARDWARE_INTEGRATION.md`
for the remaining physical-network experiment and evidence checklist.

## 6. Stop and troubleshoot

Runner cleanup leaves your original Docker services and fan terminal running.
Stop the fan with Ctrl+C; use `sudo docker compose down` when finished.

- Missing commands: install the Fedora packages in step 1; keep failed run metadata.
- MQTT port overridden: pass `--host-port 1884` and start the fan with `--port 1884`.
  Internal broker capture still uses TCP/1883.
- No publisher reading: check `publisher.log`, `relay.log`, Docker and SELinux AVCs.
  Do not disable SELinux or recursively chmod the project.
- Subnet overlap: V2 refuses conflicting routes; use another lab host or deliberately
  update the two constants and all corresponding lab addresses together.
- Count mismatch: inspect Nping/capture logs and timestamps. Low traffic is not
  evidence of a resisted attack if it never reached the target.
- Forced termination: `topology.json` lists only this run's interfaces/namespaces.
  Inspect `sudo ip netns list`; stop remaining processes in those specific namespaces
  before deleting them with `sudo ip netns delete NAME`. Remove the listed bridge's
  transient trusted-zone membership and delete that bridge. Never delete unrelated
  namespaces or the Docker network. After a reboot temporary namespaces disappear.

See `PYTHON_CODE_EXPLAINED.txt`, `TCP_V2_RESEARCH.md`,
`CHANGELOG.md` for explanations, sources and test limits.
