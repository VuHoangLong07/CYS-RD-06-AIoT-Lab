"""Export raw packet features separately from lab ground-truth annotations."""
import argparse
import csv
import json
import subprocess
from pathlib import Path

from lab_common import VICTIM, VICTIM_PORT

FIELDS = ["frame.number", "frame.time_epoch", "frame.len", "ip.src", "ip.dst", "ip.proto", "ip.ttl",
          "tcp.stream", "tcp.srcport", "tcp.dstport", "tcp.flags.syn", "tcp.flags.ack", "tcp.flags.reset",
          "tcp.len", "tcp.analysis.retransmission", "mqtt.msgtype", "mqtt.clientid", "mqtt.topic",
          "mqtt.qos", "mqtt.retain", "mqtt.msg"]


def flag_is(value, expected):
    """Tshark versions export FT_BOOLEAN as either True/False or 1/0."""
    return str(value).strip().lower() in ({"1", "true"} if expected else {"0", "false"})


def export(pcap, output):
    # Do not restrict export to MQTT: that would discard the external-victim attack.
    argv = ["tshark", "-r", str(pcap), "-Y", "ip && tcp", "-T", "fields",
            "-E", "header=y", "-E", "separator=,", "-E", "quote=d", "-E", "occurrence=f"]
    for field in FIELDS:
        argv += ["-e", field]
    with Path(output).open("w") as handle:
        subprocess.run(argv, stdout=handle, check=True)


def annotate(directory, plan):
    bot_ips = {b["ip"] for b in plan["bots"]}
    observed, reported, expected = {}, {}, {}
    actual = {}
    for bot in plan["bots"]:
        name = bot["name"]
        ip = bot["ip"]
        expected[ip] = sum(s["count"] for s in plan["segments"] if s["bot"] == name)
        path = directory/f"{name}_events.csv"
        events = []
        if path.exists():
            with path.open() as handle:
                events = list(csv.DictReader(handle))
        reported[ip] = sum(int(e["reported_sent"] or 0) for e in events)
        actual[ip] = events
        observed[ip] = 0
    with (directory/"traffic.csv").open() as handle, (directory/"labels.csv").open("w", newline="") as out:
        writer = csv.writer(out)
        writer.writerow(["frame.number", "role", "ground_truth_attack_syn"])
        for row in csv.DictReader(handle):
            ip, dst = row["ip.src"], row["ip.dst"]
            stamp = float(row["frame.time_epoch"])
            attack_syn = (ip in bot_ips and dst == VICTIM and row["tcp.dstport"] == str(VICTIM_PORT)
                          and flag_is(row["tcp.flags.syn"], True) and flag_is(row["tcp.flags.ack"], False)
                          and any(e["source_port"] == row["tcp.srcport"] and
                                  float(e["start_epoch"]) <= stamp <= float(e["end_epoch"]) for e in actual[ip]))
            if attack_syn:
                role = "attack_syn"
                observed[ip] += 1
            elif dst == VICTIM and row["tcp.dstport"] == str(VICTIM_PORT):
                role = "target_other"
            elif ip == VICTIM and row["tcp.srcport"] == str(VICTIM_PORT):
                role = "target_response"
            elif row["tcp.srcport"] == "8081" or row["tcp.dstport"] == "8081":
                role = "synthetic_beacon"
            elif row["tcp.srcport"] == "1883" or row["tcp.dstport"] == "1883":
                role = "mqtt_pipeline"
            else:
                role = "other"
            writer.writerow([row["frame.number"], role, int(attack_syn)])
    victim_counts = dict.fromkeys(bot_ips, 0)
    victim_csv = directory/"victim.csv"
    if victim_csv.exists():
        with victim_csv.open() as handle:
            for row in csv.DictReader(handle):
                ip = row["ip.src"]
                if (ip in bot_ips and row["ip.dst"] == VICTIM and row["tcp.dstport"] == str(VICTIM_PORT)
                        and flag_is(row["tcp.flags.syn"], True) and flag_is(row["tcp.flags.ack"], False)):
                    victim_counts[ip] += 1
    summary = {"per_source": {ip: {"planned_syn": expected[ip], "nping_reported_sent": reported[ip],
                                   "captured_syn": observed[ip],
                                   "captured_victim_syn": victim_counts[ip] if victim_csv.exists() else None} for ip in bot_ips},
               "total_captured_syn": sum(observed.values()),
               "note": "Counts are evidence, not proof of denial of service. Inspect capture logs for drops."}
    (directory/"syn_summary.json").write_text(json.dumps(summary, indent=2))
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_directory", type=Path)
    args = parser.parse_args()
    plan = json.loads((args.run_directory/"plan.json").read_text())
    for name in ("traffic", "broker", "victim"):
        export(args.run_directory/(name+".pcapng"), args.run_directory/(name+".csv"))
    annotate(args.run_directory, plan)


if __name__ == "__main__":
    main()
