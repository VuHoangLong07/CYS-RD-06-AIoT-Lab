# V1 → V2 changes and source audit

The uploaded ZIP was readable, including its nested `mqtt-software-lab-attacksim.zip`.
Both ZIPs passed CRC validation. The main archive has 1,102 entries; most belong
to a Python 3.14 virtual environment. The PDF has three pages, all inspected.
Both ODT containers were readable; the main ODT's text and all assets were accessible.

## Preserved byte-for-byte

`compose.yaml`, `mosquitto/mosquitto.conf`, `node-red-flow.json`,
`temperature_publisher.py`, `fan_subscriber.py`, `requirements.txt`,
`AUDIT_CORRECTIONS.md`.

The publisher is launched inside a new namespace using its existing `--host`
argument. Its source code, temperatures, payload and interval are unchanged.
The existing Node-RED controller continues to receive MQTT normally.

## Converted / replaced

- Root and `attack1-synflood/` copies of `run_tcp_burst.sh` → one `run_tcp_burst.py`.
- Root and `attack1-synflood/` copies of `capture_baseline.sh` → one `capture_baseline.py`.
- Nested ZIP's shell scripts were inspected; duplicate V1 packages are not shipped
  as runnable alternatives. The new root scripts are the authoritative versions.
- README rewritten for the actual V2 workflow; new explanation text and research added.
- The `.venv` (including its shell activation scripts) is omitted; recreate it locally.
- No `.sh` files or shell-based attack wrappers are present in this package.
  README terminal commands are commands to type, not Bash implementations.
- New support code: `lab_common.py`, `lab_services.py`, `bot_worker.py`,
  `export_dataset.py`, with focused tests in `tests/`.

## Deliberate operational changes

New routed namespaces represent three IoT bots, an egress gateway and an external
victim. A fixed MQTT relay connects bot 1 to the original loopback-bound broker.
Only the newly created bridge gets temporary firewalld trust and bridge-netfilter
settings. Gateway IP forwarding is enabled inside its namespace only. Cleanup
removes the sidecar network. Existing Docker networks and host-wide sysctls stay intact.

## Corrected V1 documentation errors

The supplied README invokes `temperature_subscriber.py`; the actual file is
`temperature_publisher.py`. It predicts about 1,500 SYNs although the provided
Nping command sends 750. It describes additional interruption/metadata behavior
that the simplified shell script does not implement. V2's README describes the
actual Python code and finite scheduled packet counts.

## Provenance retained

`reference/` contains the original ODT, explanation text, baseline PCAP,
meeting notes and two supplied V1 result folders. Those files describe V1 and
are not newly measured V2 results. Original nested ZIP / duplicated shell
scripts / nonportable dependencies are excluded to avoid mixed instructions.
`reference/archive_inventory.json` lists every uploaded archive entry and every
nested ZIP entry, with sizes and CRCs. `tests/` does not generate real attack traffic.
