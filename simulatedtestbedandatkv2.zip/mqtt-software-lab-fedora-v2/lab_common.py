"""Shared paths, subprocess calls, and an isolated, temporary routed lab."""
import json
import os
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VICTIM = "172.30.60.2"
VICTIM_PORT = 8080
LAN = "172.30.50.0/24"
WAN = "172.30.60.0/24"


def command(argv, **kwargs):
    return subprocess.run([str(x) for x in argv], check=True, **kwargs)


def require_tools(names):
    missing = [n for n in names if shutil.which(n) is None]
    if missing:
        raise RuntimeError("Install missing tools: " + ", ".join(missing))


def broker_info():
    result = command(["docker", "compose", "-f", ROOT / "compose.yaml",
                      "ps", "-q", "mosquitto"], capture_output=True, text=True)
    container = result.stdout.strip()
    if not container or "\n" in container:
        raise RuntimeError("Start exactly one Mosquitto service in this Compose project")
    info = json.loads(command(["docker", "inspect", container],
                             capture_output=True, text=True).stdout)[0]
    if not info["State"]["Running"]:
        raise RuntimeError("Mosquitto is not running")
    return {"container": container, "pid": info["State"]["Pid"],
            "networks": info["NetworkSettings"]["Networks"]}


def restore_owner(path):
    """Return only this newly-created result tree to the invoking sudo user."""
    uid, gid = int(os.environ.get("SUDO_UID", os.getuid())), int(os.environ.get("SUDO_GID", os.getgid()))
    for p in [Path(path), *Path(path).rglob("*")]:
        if not p.is_symlink():
            os.chown(p, uid, gid)


class Topology:
    """No default routes, no NAT, no host-wide forwarding/firewall changes."""
    def __init__(self, tag, bots=3):
        self.tag = tag
        self.bridge = tag + "br"
        self.namespaces = []
        self.links = []
        self.firewall_added = False
        self.bots = [(tag + f"b{i}", f"172.30.50.{10+i}") for i in range(1, bots+1)]
        self.gateway, self.target = tag + "gw", tag + "dst"

    def ns(self, name, argv, **kwargs):
        return command(["ip", "netns", "exec", name, *argv], **kwargs)

    def endpoint(self, name, host_if, ns_if, address, bridge=None):
        # Never create an 'eth0' peer in the host: that name may already be in use.
        peer = self.tag + "p" + host_if[-1]
        command(["ip", "link", "add", host_if, "type", "veth", "peer", "name", peer])
        self.links.append(host_if)
        command(["ip", "link", "set", peer, "netns", name])
        self.ns(name, ["ip", "link", "set", peer, "name", ns_if])
        if bridge:
            command(["ip", "link", "set", host_if, "master", bridge])
        command(["ip", "link", "set", host_if, "up"])
        self.ns(name, ["ip", "addr", "add", address, "dev", ns_if])
        self.ns(name, ["ip", "link", "set", ns_if, "up"])

    def start(self):
        # Refuse overlaps rather than changing another project's addressing.
        routes = json.loads(command(["ip", "-j", "-4", "route", "show", "table", "all"],
                                    capture_output=True, text=True).stdout)
        import ipaddress
        for route in routes:
            dest = route.get("dst", "default")
            if dest == "default":
                continue
            network = ipaddress.ip_network(dest, strict=False)
            if any(network.overlaps(ipaddress.ip_network(n)) for n in (LAN, WAN)):
                raise RuntimeError(f"Lab subnet overlaps host route {dest}; choose a different lab host")
        try:
            for name in [*[b[0] for b in self.bots], self.gateway, self.target]:
                command(["ip", "netns", "add", name])
                self.namespaces.append(name)
                self.ns(name, ["ip", "link", "set", "lo", "up"])
            command(["ip", "link", "add", self.bridge, "type", "bridge"])
            self.links.append(self.bridge)
            command(["ip", "addr", "add", "172.30.50.1/24", "dev", self.bridge])
            command(["ip", "link", "set", self.bridge, "up"])
            # Scope bridge-netfilter changes to our bridge, never to host sysctls.
            command(["ip", "link", "set", self.bridge, "type", "bridge",
                     "nf_call_iptables", "0", "nf_call_ip6tables", "0"])
            if shutil.which("firewall-cmd") and subprocess.run(
                    ["firewall-cmd", "--state"], capture_output=True).returncode == 0:
                command(["firewall-cmd", "--zone=trusted", "--add-interface="+self.bridge],
                        capture_output=True)
                self.firewall_added = True
            for i, (name, addr) in enumerate(self.bots, 1):
                self.endpoint(name, self.tag+f"v{i}", "eth0", addr+"/24", self.bridge)
                self.ns(name, ["ip", "route", "add", WAN, "via", "172.30.50.254"])
            self.endpoint(self.gateway, self.tag+"vg", "lan0", "172.30.50.254/24", self.bridge)
            # A veth directly joins gateway WAN to target; no link to the internet.
            a, b = self.tag+"wa", self.tag+"wb"
            command(["ip", "link", "add", a, "type", "veth", "peer", "name", b])
            self.links.append(a)
            command(["ip", "link", "set", a, "netns", self.gateway])
            command(["ip", "link", "set", b, "netns", self.target])
            self.ns(self.gateway, ["ip", "link", "set", a, "name", "wan0"])
            self.ns(self.target, ["ip", "link", "set", b, "name", "eth0"])
            for name, interface, addr in [(self.gateway, "wan0", "172.30.60.1/24"),
                                          (self.target, "eth0", VICTIM+"/24")]:
                self.ns(name, ["ip", "addr", "add", addr, "dev", interface])
                self.ns(name, ["ip", "link", "set", interface, "up"])
            self.ns(self.gateway, ["sysctl", "-q", "-w", "net.ipv4.ip_forward=1"])
            self.ns(self.target, ["ip", "route", "add", LAN, "via", "172.30.60.1"])
        except BaseException:
            self.close()
            raise

    def close(self):
        # Called after all our processes have been stopped.
        if self.firewall_added:
            subprocess.run(["firewall-cmd", "--zone=trusted", "--remove-interface="+self.bridge],
                           capture_output=True)
            self.firewall_added = False
        for name in reversed(self.namespaces):
            subprocess.run(["ip", "netns", "del", name], capture_output=True)
        self.namespaces.clear()
        for link in reversed(self.links):
            subprocess.run(["ip", "link", "del", link], capture_output=True)
        self.links.clear()
