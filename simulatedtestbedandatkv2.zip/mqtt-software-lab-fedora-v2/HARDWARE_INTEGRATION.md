# Physical integration — what remains to demonstrate

The meeting's required outcome is real-device traffic, attack traffic and model
results together. This software kit prepares an outbound behavioral experiment;
it does not claim that physical integration has already happened.

## Two distinct experiments

| Experiment | What it answers | Current V2 support |
| --- | --- | --- |
| Compromised nodes send outbound traffic to a separate victim | Can the detector flag egress while MQTT still works? | Fully specified software topology and runner; real MQTT can be captured concurrently |
| Physical Arduino/broker under direct availability pressure | What resource/message bottlenecks occur, and does detection work? | Not implemented here; still requested by the instructor, to coordinate on the actual physical testbed |

Do not call concurrent capture a shared-resource stress experiment. V2's isolated
virtual links do not consume the Arduino's real Wi-Fi bandwidth and do not make
its firmware send SYN packets. Low-rate traffic may cause no hardware impairment.

## Practical sequence with the testbed engineer

1. Confirm the actual physical path from the notes: UNO R4 sensor → MQTT broker
   → Node-RED → UNO R4 actuator. Record IPs, topics, sensor interval, firmware,
   broker address/port, QoS and capture point from the running setup.
2. Capture a clean real-device baseline with sequence numbers/timestamps if the
   existing firmware already supports them. The virtual temperature/fan scripts
   are not substitutes for the real distance-sensor/LED payloads.
3. Run the V2 software smoke test first. Then use --no-publisher and the actual
   SPAN/TAP/capture NIC while physical telemetry continues. This is a useful
   synchronized mixed dataset, explicitly labeled as real MQTT plus emulated bots.
4. To measure actual egress contention, arrange a separate Linux attack emulator
   on the physical lab's shared gateway/link and an isolated local victim beyond
   that gateway. Confirm capture sees both directions. Agree this topology with
   the testbed engineer; no unknown Arduino wiring/firmware instructions are invented.
5. Use finite low-rate trials first; record device effects before considering any
   higher-pressure availability test. Keep source/victim identities and gateway
   configuration documented. Do not assume a TCP-connect burst from firmware is
   equivalent to raw SYN flooding; completed handshakes model different behavior.
6. Pass observed CSVs/labels to the ML owner. Report detected/missed/false alarms
   on whole held-out runs and include a no-attack control. The script does not
   contain or fabricate a detection model.

## Observation sheet — fill from measurements

Copy this into each run's notes; leave unknown values blank rather than inventing them.

| Measurement | Baseline | Attack | Recovery | How obtained |
| --- | --- | --- | --- | --- |
| Actual publish interval / record count | | | | Device logs / decoded complete MQTT records |
| Sequence gaps | | | | Existing device sequence field; document resets |
| Acknowledgement delay | | | | Matched PUBLISH/PUBACK or device instrumentation |
| Actuator command-to-observed-action delay | | | | Command log + real actuator observation |
| Reconnects / time disconnected | | | | Broker and device logs |
| Buffer/queue drops | | | | Firmware counters if available; not inferred from silence |
| Arduino memory/resource symptoms | | | | Existing firmware instrumentation/serial logs |
| Broker CPU/memory/network use | | | | Host/container measurements with timestamps |
| Capture received/dropped packets | | | | Each dumpcap capture log |
| ML alerts/scores and false positives | | | | Model output on these actual runs |

Retain failures and no-effect results. A stable broker with detected abnormal
outbound behavior is a valid result for the external-victim experiment.
