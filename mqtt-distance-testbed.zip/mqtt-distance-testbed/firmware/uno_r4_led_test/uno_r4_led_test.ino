// UNO R4 WiFi: blink built-in L LED first. Optional external LED uses pin 7.
const int LED_PIN = LED_BUILTIN;
void setup() { pinMode(LED_PIN, OUTPUT); }
void loop() {
  digitalWrite(LED_PIN, HIGH);
  delay(1000);
  digitalWrite(LED_PIN, LOW);
  delay(1000);
}
