"""V2: bounded multi-source SYN traffic to an isolated routed victim while MQTT continues."""
import argparse
import csv
import json
import os
import random
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from export_dataset import annotate, export
from lab_common import ROOT, VICTIM, VICTIM_PORT, Topology, broker_info, command, require_tools, restore_owner


def build_plan(seconds=120, bots=3, seed=42, control=False):
    rng = random.Random(seed)
    nodes = [{"name": f"bot{i}", "ip": f"172.30.50.{10+i}"} for i in range(1, bots+1)]
    segments = []
    if not control:
        for bot in nodes:
            offset = rng.uniform(0.2, 1.0)
            while offset + 2 < seconds:
                duration = min(rng.randint(3, 5), int(seconds-offset-1))
                rate = rng.choice([2, 3, 5])
                segments.append({"bot": bot["name"], "offset": round(offset, 6), "rate": rate,
                                 "count": duration*rate, "source_port": rng.randint(49152, 65535)})
                # Gap permits slight scheduler overhead; variability is experimental, not an evasion claim.
                offset += duration + rng.uniform(0.5, 1.5)
    return {"seed": seed, "bots": nodes, "victim": VICTIM, "victim_port": VICTIM_PORT,
            "attack_seconds": seconds, "control": control, "segments": segments,
            "planned_syn": sum(s["count"] for s in segments)}


def wait_ready(path, process, timeout=10):
    end = time.monotonic()+timeout
    while time.monotonic() < end:
        if process.poll() is not None:
            raise RuntimeError(f"Process exited before readiness; inspect {path.name}")
        if path.exists() and path.stat().st_size > 0:
            return
        time.sleep(0.1)
    raise TimeoutError(f"No readiness signal from {path.name}")


def stop_process(process, interrupt=False):
    if process.poll() is None:
        try:
            os.killpg(process.pid, signal.SIGINT if interrupt else signal.SIGTERM)
        except ProcessLookupError:
            return
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                return
            process.wait(timeout=3)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=int, default=60)
    parser.add_argument("--attack", type=int, default=120)
    parser.add_argument("--recovery", type=int, default=60)
    parser.add_argument("--bots", type=int, choices=[1, 2, 3], default=3)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--host-port", type=int, default=1883)
    parser.add_argument("--python", default=str(ROOT/".venv/bin/python"), help="Venv interpreter with paho-mqtt")
    parser.add_argument("--no-publisher", action="store_true", help="Use independently running hardware telemetry")
    parser.add_argument("--mqtt-interface", help="Host SPAN/TAP/NIC for hardware; default captures Docker broker")
    parser.add_argument("--control", action="store_true", help="Same setup, duration and heartbeats, zero attack SYNs")
    parser.add_argument("--quick", action="store_true", help="Short smoke run: 2/6/2 seconds")
    parser.add_argument("--dry-run", action="store_true", help="Create plan only; no sudo, topology or traffic")
    args = parser.parse_args()
    if args.quick:
        args.baseline, args.attack, args.recovery = 2, 6, 2
    if not all(1 <= n <= 300 for n in (args.baseline, args.attack, args.recovery)):
        parser.error("Each phase must be 1..300 seconds")
    if not 1024 <= args.host_port <= 65535:
        parser.error("host port must be 1024..65535")
    plan = build_plan(args.attack, args.bots, args.seed, args.control)
    if not args.control and not plan["planned_syn"]:
        parser.error("Attack window is too short to contain a finite segment; use at least 4 seconds")
    run = ROOT/"results"/("tcp-v2-"+datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")+"-"+uuid.uuid4().hex[:6])
    run.mkdir(parents=True)
    (run/"plan.json").write_text(json.dumps(plan, indent=2))
    print("Results:", run, flush=True)
    if args.dry_run:
        print("Plan only:", plan["planned_syn"], "SYNs; no traffic generated")
        restore_owner(run)
        return 0
    if os.geteuid() != 0:
        parser.error("Use sudo python3 run_tcp_burst.py ... (or --dry-run)")
    metadata = {"status": "incomplete", "parameters": vars(args), "plan": plan,
                "physical_hardware_verified": False, "capture_points": ["isolated LAN bridge", "MQTT broker or supplied NIC", "victim eth0"],
                "core_testbed_files_changed": False, "python_version": sys.version}
    topology = Topology("v2"+uuid.uuid4().hex[:5], args.bots)
    processes, captures, logs = [], [], []
    temporary = None
    failure = None
    publisher = None
    worker_processes = []
    def spawn(argv, filename):
        handle = (run/filename).open("w")
        logs.append(handle)
        process = subprocess.Popen([str(x) for x in argv], stdout=handle, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        processes.append(process)
        return process
    def mark(event):
        with (run/"timeline.csv").open("a", newline="") as handle:
            csv.writer(handle).writerow([event, datetime.now(timezone.utc).isoformat(), time.time(), time.monotonic()])
        print(event, flush=True)
    def phase_wait(seconds):
        end = time.monotonic()+seconds
        while time.monotonic() < end:
            for process in [*captures, *processes]:
                if process.poll() is not None:
                    raise RuntimeError("A service, worker or capture exited early; inspect logs")
            time.sleep(min(0.1, max(0, end-time.monotonic())))
    try:
        require_tools(["ip", "sysctl", "nping", "dumpcap", "tshark", "docker", "nsenter"])
        broker = broker_info()
        metadata["broker"] = broker
        metadata["nping_version"] = command(["nping", "--version"], capture_output=True, text=True).stdout
        metadata["tshark_version"] = command(["tshark", "--version"], capture_output=True, text=True).stdout.splitlines()[0]
        with socket.create_connection(("127.0.0.1", args.host_port), timeout=5):
            pass
        interpreter = Path(args.python).expanduser().absolute()
        if not args.no_publisher:
            command([interpreter, "-c", "import paho.mqtt.client"], capture_output=True)
        topology.start()
        metadata["topology"] = {"bridge": topology.bridge, "namespaces": topology.namespaces,
                                "transient_firewalld_trusted_interface": topology.firewall_added}
        (run/"topology.json").write_text(json.dumps(metadata["topology"], indent=2))
        ready = run/"target.ready"
        process = spawn(["ip", "netns", "exec", topology.target, sys.executable,
                         ROOT/"lab_services.py", "target", "--ready-file", ready], "target.log")
        wait_ready(ready, process)
        if not args.no_publisher:
            ready = run/"relay.ready"
            process = spawn([sys.executable, ROOT/"lab_services.py", "relay", "--host-port", args.host_port,
                             "--ready-file", ready], "relay.log")
            wait_ready(ready, process)
        temporary = Path(tempfile.mkdtemp(prefix="tcp-v2-capture."))
        temporary.chmod(0o1777)
        for name, prefix, interface, bpf in [
                ("traffic", [], topology.bridge, "tcp"),
                ("broker", [] if args.mqtt_interface else ["nsenter", "-t", str(broker["pid"]), "-n", "--"],
                 args.mqtt_interface or "any", "tcp port 1883"),
                ("victim", ["ip", "netns", "exec", topology.target], "eth0", "tcp port 8080 or tcp port 8081")]:
            process = spawn([*prefix, "dumpcap", "-i", interface, "-f", bpf,
                             "-a", f"duration:{args.baseline+args.attack+args.recovery+60}",
                             "-w", temporary/(name+".pcapng")], name+"_capture.log")
            captures.append(process)
            wait_ready(temporary/(name+".pcapng"), process)
        if not args.no_publisher:
            publisher = spawn(["ip", "netns", "exec", topology.bots[0][0], interpreter, "-u",
                               ROOT/"temperature_publisher.py", "--host", "172.30.50.1"], "publisher.log")
            end = time.monotonic()+15
            while "SENT " not in (run/"publisher.log").read_text():
                if publisher.poll() is not None or time.monotonic() >= end:
                    raise RuntimeError("Publisher produced no acknowledged reading; inspect publisher/relay logs")
                time.sleep(0.1)
        (run/"timeline.csv").write_text("event,time_utc,epoch,monotonic\n")
        attack_start = time.monotonic()+args.baseline
        for index, (namespace, addr) in enumerate(topology.bots, 1):
            process = spawn(["ip", "netns", "exec", namespace, sys.executable, ROOT/"bot_worker.py",
                             "--plan", run/"plan.json", "--bot", f"bot{index}", "--start", attack_start,
                             "--stop-file", run/"workers.stop", "--output", run], f"bot{index}_worker.log")
            worker_processes.append(process)
        mark("baseline_start")
        phase_wait(max(0, attack_start-time.monotonic()))
        mark("attack_start" if not args.control else "control_window_start")
        phase_wait(args.attack)
        mark("attack_end" if not args.control else "control_window_end")
        # A late Nping segment must not leak into the recovery stage.
        (run/"attack.stop").touch()
        for index, process in enumerate(worker_processes, 1):
            wait_ready(run/f"bot{index}_syn_done", process)
        mark("recovery_start")
        phase_wait(args.recovery)
        mark("recovery_end")
        (run/"workers.stop").touch()
        for process in worker_processes:
            process.wait(timeout=10)
            processes.remove(process)
        metadata["status"] = "captured"
    except (Exception, KeyboardInterrupt) as exc:
        failure = str(exc) or "Interrupted by user"
        metadata["error"] = failure
        print("Incomplete run:", failure, file=sys.stderr)
    finally:
        (run/"workers.stop").touch()
        for process in worker_processes:
            if process.poll() is None:
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    stop_process(process)
        metadata["worker_exit_codes"] = [p.returncode for p in worker_processes]
        for process in reversed(processes):
            stop_process(process, process in captures)
        for handle in logs:
            handle.close()
        if temporary:
            for path in temporary.glob("*.pcapng"):
                shutil.copy2(path, run/path.name)
            shutil.rmtree(temporary)
        topology.close()
    if metadata["status"] == "captured":
        try:
            for name in ("traffic", "broker", "victim"):
                export(run/(name+".pcapng"), run/(name+".csv"))
            summary = annotate(run, plan)
            with (run/"broker.csv").open() as handle:
                mqtt_rows = list(csv.DictReader(handle))
            metadata["mqtt_publish_packets"] = sum(row["mqtt.msgtype"] == "3" for row in mqtt_rows)
            metadata["broker_pid_end"] = broker_info()["pid"]
            if metadata["broker_pid_end"] != metadata["broker"]["pid"]:
                metadata["status"] = "broker_restarted"
                failure = "Broker namespace changed during capture; repeat the run"
            elif not metadata["mqtt_publish_packets"]:
                metadata["status"] = "no_mqtt_evidence"
                failure = "MQTT capture contains no PUBLISH packets; check telemetry and capture placement"
            elif any(p.returncode != 0 for p in worker_processes) or any(
                    item["planned_syn"] != item["nping_reported_sent"] or
                    item["captured_syn"] != item["nping_reported_sent"] or
                    item["captured_victim_syn"] != item["nping_reported_sent"]
                    for item in summary["per_source"].values()):
                metadata["status"] = "counts_mismatch"
                failure = "Planned/sent/captured counts differ; inspect logs before using this run"
            else:
                metadata["status"] = "complete"
        except Exception as exc:
            metadata["status"] = "export_failed"
            metadata["error"] = str(exc)
            failure = str(exc)
    if failure:
        metadata["error"] = failure
    (run/"metadata.json").write_text(json.dumps(metadata, indent=2))
    restore_owner(run)
    print("Status:", metadata["status"], "Results:", run)
    return 0 if metadata["status"] == "complete" else 1


if __name__ == "__main__":
    raise SystemExit(main())
