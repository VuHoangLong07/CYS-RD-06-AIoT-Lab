"""Fixed lab TCP target, heartbeat stub and loopback MQTT relay. No arbitrary forwarding."""
import argparse
import json
import select
import socket
import socketserver
import threading

from lab_common import VICTIM, VICTIM_PORT


class TCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


class Sink(socketserver.BaseRequestHandler):
    def handle(self):
        self.request.settimeout(2)
        try:
            self.request.recv(128)
        except OSError:
            pass


class Heartbeat(socketserver.BaseRequestHandler):
    def handle(self):
        self.request.settimeout(2)
        try:
            self.request.recv(128)
            self.request.sendall(json.dumps({"lab_ack": True}).encode()+b"\n")
        except OSError:
            pass


def relay_handler(port):
    class Relay(socketserver.BaseRequestHandler):
        def handle(self):
            try:
                # Only the existing host MQTT broker; destination cannot be supplied by clients.
                with socket.create_connection(("127.0.0.1", port), timeout=5) as upstream:
                    self.request.settimeout(5)
                    while True:
                        readable, _, _ = select.select([self.request, upstream], [], [], 1)
                        for source in readable:
                            data = source.recv(65536)
                            if not data:
                                return
                            other = upstream if source is self.request else self.request
                            other.sendall(data)
            except OSError as exc:
                print("Relay connection ended:", exc, flush=True)
    return Relay


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["target", "relay"])
    parser.add_argument("--host-port", type=int, default=1883)
    parser.add_argument("--ready-file", required=True)
    args = parser.parse_args()
    servers = []
    try:
        if args.mode == "target":
            servers = [TCPServer((VICTIM, VICTIM_PORT), Sink), TCPServer((VICTIM, 8081), Heartbeat)]
        else:
            if not 1024 <= args.host_port <= 65535:
                parser.error("host port must be 1024..65535")
            # Verify upstream first so an unavailable broker cannot silently pass setup.
            with socket.create_connection(("127.0.0.1", args.host_port), timeout=5):
                pass
            servers = [TCPServer(("172.30.50.1", 1883), relay_handler(args.host_port))]
        from pathlib import Path
        for server in servers:
            threading.Thread(target=server.serve_forever, daemon=True).start()
        Path(args.ready_file).write_text("ready\n")
        threading.Event().wait()
    finally:
        for server in servers:
            server.server_close()


if __name__ == "__main__":
    main()
