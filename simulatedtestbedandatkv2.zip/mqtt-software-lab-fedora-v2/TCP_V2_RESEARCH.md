# Attack 1 — bounded outbound TCP SYN traffic, V2

## Motivation and actual precedent

Mirai is the precedent for compromised IoT devices acting as infrastructure for
attacks against other systems. Antonakakis et al. studied its 2016 growth and
DDoS victims, including a peak around 600,000 infections [1]. This supports the
botnet/external-victim model. It does **not** justify claiming that our chosen
2–5 packets/second, source-port changes or timing gaps reproduce Mirai exactly.

The uploaded ODT already distinguishes attacks on an external victim from
attacks on the local MQTT broker. The meeting notes ask for less obvious
patterns, Python, breadth and physical integration. V2 models outbound traffic
and continued MQTT operation; it is not the separate requested experiment of
measuring the physical broker/UNO R4 under direct availability pressure.

## Threat model and TTPs

The assumed attacker already controls the emulated nodes and wants to use their
connectivity against a third-party service. Initial compromise is a precondition,
not something this code performs. The fixed victim is inside an isolated lab.

| Layer | V2 behavior | What the evidence can establish |
| --- | --- | --- |
| Tactic | Impact / denial-of-service objective | Research framing; no outage claimed |
| Technique | ATT&CK T1498.001, Direct Network Flood [2] | SYN packet pattern associated with that technique |
| Procedure | Three real network namespaces, each with its own source IP, send finite SYN segments through a gateway | Multiple sources and routed target reachability |
| Traffic variability | Source port changes by segment; seeded onset, rate and gap changes | Known controlled variability, not validated IDS evasion |
| Background workload | Bot 1 runs the unchanged MQTT publisher; Node-RED and fan continue | Same device address emits telemetry and outbound SYNs on LAN capture |
| C2 observable | Fixed heartbeat request/reply throughout all phases and control runs | Synthetic background beacon traffic only; no network-delivered attack commands |
| Data handoff | Three PCAP viewpoints, raw CSV, separate ground truth and actual events | Reproducible sender/receiver evidence and transparent failures |

Bots 2/3 do not run real firmware or independent sensors. There is no source-IP
spoofing, propagation, persistence, traffic laundering or detection bypass.
Changing destination ports indiscriminately would model scanning rather than
an attack on one known service, so destination port remains 8080.

## Cyber Kill Chain mapping

The seven stages follow Lockheed Martin's framework [3]. This is an analytical
mapping, not evidence that every stage was performed in our lab.

| Stage | Plausible botnet context | Implemented in V2? |
| --- | --- | --- |
| 1. Reconnaissance | Find potentially accessible devices | No; compromise assumed |
| 2. Weaponization | Prepare device-compatible bot capabilities | No malware is built |
| 3. Delivery | Transfer malicious code to a device | No |
| 4. Exploitation | Obtain unauthorized execution | No |
| 5. Installation | Establish bot execution | No; namespaces are explicit emulators |
| 6. Command and Control | Coordinate bots | Heartbeat stub only; local experiment coordinator controls the schedule |
| 7. Actions on Objectives | Direct traffic against the selected victim | Bounded SYN traffic is the implemented action |

## What V2 fixes, and what remains

The victim is on another subnet with an explicit gateway, rather than the
broker with a new name. Per-node traffic is lower than V1, with multiple real
source addresses and recorded variation. The capture/export path no longer
throws away everything outside TCP/1883. Planned/sent/LAN/victim counts must
agree; missing telemetry or process errors are flagged. A no-SYN control run
uses the same infrastructure, telemetry and heartbeat behavior.

A SYN sends the first step of TCP's connection handshake. Think of knocking
at a door and never finishing the conversation. Here Nping sends the knock;
the node OS may send a reset when the victim replies. Therefore this setup is
a **SYN-pattern traffic emulation**, not proof of sustained half-open backlog
exhaustion. Three low-rate nodes may not impair any modern TCP service.
SYN cookies, queue limits, kernel resets and available resources affect outcomes.

The chosen low rates and variability make the dataset less tied to a single
large-rate threshold; they do not establish realistic evasion success. Source
identity and fixed victim IP are also shortcuts: exclude identifiers from the
model and evaluate unseen runs/benign reconnections. Source rotation by itself
is not malicious, and irregular timing is not proof of compromise.

There is no real internet/NAT, WAN delay, physical Wi-Fi contention, infected
Arduino firmware or hardware performance result here. The external scenario
can preserve broker availability; absence of broker failure is not evidence
that the attack was absent. To test hardware effects later, place the emulated
outbound activity on the actual shared lab path and measure resource limits,
while maintaining an isolated local victim.

## Suggested evidence to bring

- Clean control and attack runs with other seeds; all four count columns match.
- The fan log and Node-RED readings remain present during the attack window.
- Per-source/time-window connection behavior and the ML model's scores.
- False positives from an explicitly labeled benign reconnect run, kept separate.
- Failed/incomplete runs retained, rather than silently relabeled as successful.
- Actual Arduino sequence gaps, acknowledgement delays and reconnect counts only
  after the physical shared-path integration has been carried out.

## Sources — primary references

[1] Antonakakis et al. (2017), *Understanding the Mirai Botnet*, USENIX Security.
https://www.usenix.org/conference/usenixsecurity17/technical-sessions/presentation/antonakakis

[2] MITRE ATT&CK, T1498.001 — Direct Network Flood.
https://attack.mitre.org/techniques/T1498/001/

[3] Hutchins, Cloppert and Amin, Lockheed Martin, *Intelligence-Driven Computer
Network Defense Informed by Analysis of Adversary Campaigns and Intrusion Kill Chains*.
https://www.lockheedmartin.com/content/dam/lockheed-martin/rms/documents/cyber/LM-White-Paper-Intel-Driven-Defense.pdf

Local references: `reference/V1_ATKSim1.odt` and `reference/Meeting_Week_05.pdf`.
Sources checked 13 October 2026. Lab choices and suggested ML features are our
experimental design, not performance results reported by these sources.
