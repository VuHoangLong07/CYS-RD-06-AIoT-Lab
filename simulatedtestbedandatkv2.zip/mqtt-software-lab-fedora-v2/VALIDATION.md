# Validation performed — 13 October 2026

## Passed

- Main ZIP: all 1,102 entries accessible and CRC-checked.
- Nested attack ZIP: all three entries accessible and CRC-checked.
- Main and nested ODT: all container assets readable, CRCs and content XML valid.
- Meeting PDF: all three pages extracted and visually inspected.
- All seven preserved core/testbed files compared byte-for-byte with the upload.
- Compose YAML and Node-RED JSON parse successfully. This is not a Docker
  Compose schema check or a runtime deployment test.
- Every new Python script compiled successfully.
- Eleven focused automated tests passed. They cover bounded/repeatable schedules,
  no-attack controls, explicit routes/no default route, namespace-scoped forwarding,
  unique veth peer names, cleanup after partial setup failure, readiness rejection,
  packet-label separation, duplicate receiver evidence, TCP export without shell
  execution, bidirectional relay transport, fixed heartbeat replies, and mocked
  worker send-count handling.
- Boolean-field compatibility checked against the supplied real V1 CSV: all 750
  injected SYNs were recognized despite its True/False field formatting.
- Loopback relay and heartbeat transport tested with real local TCP sockets.
  Those tests do not generate SYN-attack traffic or use Docker/MQTT.
- Dry runs generate valid finite plans. Seed 42/default: 945 planned SYNs;
  quick mode: 36; control: zero. These are planned values, not measurements.
- A live-run preflight in this workspace correctly returned `incomplete` and
  identified missing nping, dumpcap, tshark and Docker, rather than reporting success.

## Not verified here

This workspace does not provide Docker, Nping, dumpcap or tshark. Attempting
namespace creation also returned `Cannot open netlink socket: Operation not
permitted`. Consequently the following checks remain for the Fedora lab:

- Actual namespace creation, scoped firewalld/bridge settings and cleanup.
- Docker image availability/startup, actual Node-RED deployment and MQTT actuation.
- Real Nping execution, raw packet spacing, kernel RST behavior and counts.
- LAN bridge capture visibility and victim delivery, capture loss and export field support.
- SELinux behavior and dumpcap privilege dropping in the real installed environment.
- Physical Arduino telemetry, buffering, shared-link contention or attack effects.
- Any ML training, accuracy, false-positive rate or detection result.

No V2 observed dataset, outage or hardware performance claim is included.
V1 PCAP/CSV files in reference/ are the supplied historical files, not V2 output.

## First local acceptance check

Start the original testbed and fan, then follow README step 3's `--quick` command.
Inspect metadata.json and all capture logs. Confirm the victim SYN count matches
sender and LAN counts, MQTT PUBLISH traffic exists, and the virtual fan responds.
Then record the four-minute run, a matched control and repeated seeds. Keep failed
runs as evidence. A clean software run still does not satisfy the separate physical
integration milestone described in HARDWARE_INTEGRATION.md.
